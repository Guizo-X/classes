public class Caminhao extends Veiculo {

    private String capacidadeDeCarga;

    public Caminhao(String marca, String modelo, double preco) {
        super(marca, modelo, preco);
    }


}
