public class Moto extends Veiculo {

    private String facilidaDeEstacionamento;

    public Moto(String marca, String modelo, double preco) {
        super(marca, modelo, preco);
    }


}
