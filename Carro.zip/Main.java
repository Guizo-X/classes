import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.printf("qual seu veiculo? %n carro %n moto %n caminhao(escreva caminhao sem acento)");
        String escolha = s.next().toLowerCase();

        switch (escolha){

            case "carro":
                System.out.println("digite o preço do carro: ");
                double p = s.nextDouble();
                System.out.println("digite a marca do carro: ");
                String marcaCar = s.next();
                System.out.println("digite o modelo do carro: ");
                String modeloCar = s.next();
                Veiculo v = new Carro(marcaCar,modeloCar,p);
                System.out.println(v.getMarca());
                System.out.println(v.getModelo());
                System.out.println(v.IPVA());
            break;
            case "moto":
                System.out.println("digite o preço do moto: ");
                double p1 = s.nextDouble();
                System.out.println("digite a marca do moto: ");
                String marcaMoto = s.next();
                System.out.println("digite o modelo do moto: ");
                String modeloMoto = s.next();
                Veiculo v1 = new Moto(marcaMoto,modeloMoto,p1);
                System.out.println(v1.getMarca());
                System.out.println(v1.getModelo());
                System.out.println(v1.IPVA());
            break;
            case "caminhao":
                System.out.println("digite o preço do caminhao: ");
                double p2 = s.nextDouble();
                System.out.println("digite a marca do caminhao: ");
                String marcaCam = s.next();
                System.out.println("digite o modelo do caminhao: ");
                String modeloCam = s.next();
                Veiculo v2 = new Caminhao(marcaCam,modeloCam,p2);
                System.out.println(v2.getMarca());
                System.out.println(v2.getModelo());
                System.out.println(v2.IPVA());
            break;
        }

        System.out.println("digite o preço do veiculo");
        double p = s.nextDouble();



        Veiculo v = new Moto("honda","sivic",p);

        System.out.println(v.IPVA());

    }
}
