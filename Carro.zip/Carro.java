public class Carro extends Veiculo {

    private String versatilidade;

    public Carro(String marca, String modelo, double preco) {
        super(marca, modelo, preco);
    }
}
